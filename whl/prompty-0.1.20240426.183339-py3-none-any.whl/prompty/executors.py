import json
from openai import AzureOpenAI
from pydantic import BaseModel
from .core import Invoker, InvokerFactory, Prompty, SimpleModel
from .tracer import current_tracer


class AzureOpenAIExecutor(Invoker):
    def __init__(self, prompty: Prompty) -> None:
        self.prompty = prompty
        self.client = AzureOpenAI(
            default_headers={"User-Agent": "prompty/0.1.0"},
            **{
                key: value
                for key, value in self.prompty.model.configuration.items()
                if key != "type"
            },
        )

        self.api = self.prompty.model.api
        self.deployment = self.prompty.model.configuration["azure_deployment"]
        self.parameters = self.prompty.model.parameters

    def _write_spans(self, span, values: dict):
        for attribute, value in values.items():
            span.set_attribute(attribute, value)

    def invoke(self, data: BaseModel) -> BaseModel:
        assert isinstance(data, SimpleModel)
        if self.api == "chat":
            with current_tracer().start_as_current_span(
                "AzureOpenAIChat"
            ) as span:
                span.set_attribute("signature", "AzureOpenAI.chat.completions.create")
                span.set_attribute(
                    "input",
                    json.dumps(
                        {
                            "api": self.api,
                            "messages": data.item,
                            "model": self.deployment,
                            "parameters": self.parameters,
                        }
                    ),
                )
                response = self.client.chat.completions.create(
                    model=self.deployment,
                    messages=data.item,
                    **self.parameters,
                )

                span.set_attribute(
                    "completion_tokens", response.usage.completion_tokens
                )
                span.set_attribute("prompt_tokens", response.usage.prompt_tokens)
                span.set_attribute("total_tokens", response.usage.total_tokens)
                span.set_attribute("result", response.model_dump_json())
        elif self.api == "completion":
            with current_tracer().start_as_current_span(
                "AzureOpenAICompletion"
            ) as span:
                span.set_attribute("signature", "AzureOpenAI.completions.create")
                span.set_attribute(
                    "input",
                    json.dumps(
                        {
                            "api": self.api,
                            "prompt": data.item,
                            "model": self.deployment,
                            "parameters": self.parameters,
                        }
                    ),
                )
                response = self.client.completions.create(
                    prompt=data.item,
                    model=self.deployment,
                    **self.parameters,
                )
                span.set_attribute(
                    "completion_tokens", response.usage.completion_tokens
                )
                span.set_attribute("prompt_tokens", response.usage.prompt_tokens)
                span.set_attribute("total_tokens", response.usage.total_tokens)
                span.set_attribute("result", response.model_dump_json())
        elif self.api == "embedding":
            with current_tracer().start_as_current_span(
                "AzureOpenAIEmbedding"
            ) as span:
                span.set_attribute("signature", "AzureOpenAI.embeddings.create")
                span.set_attribute(
                    "input",
                    json.dumps(
                        {
                            "api": self.api,
                            "documents": data.item,
                            "model": self.deployment,
                            "parameters": self.parameters,
                        }
                    ),
                )
                response = self.client.embeddings.create(
                    input=data.item if isinstance(data.item, list) else [data.item],
                    model=self.deployment,
                    **self.parameters,
                )
                span.set_attribute("prompt_tokens", response.usage.prompt_tokens)
                span.set_attribute("total_tokens", response.usage.total_tokens)
                span.set_attribute("result", response.model_dump_json())
        elif self.api == "image":
            raise NotImplementedError("Azure OpenAI Image API is not implemented yet")

        return response


InvokerFactory().register_executor("azure", AzureOpenAIExecutor)
